import { ethers } from "ethers"

// Connect to local Ethereum node
const provider = new ethers.JsonRpcProvider("http://localhost:8545")

export async function getLatestBlocks(count = 10) {
  try {
    const blockNumber = await provider.getBlockNumber()
    const blocks = []

    for (let i = 0; i < count; i++) {
      if (blockNumber - i < 0) break
      const block = await provider.getBlock(blockNumber - i)
      if (block) {
        blocks.push(block)
      }
    }

    return blocks
  } catch (error) {
    console.error("Error fetching blocks:", error)
    return []
  }
}

export async function getBlockByHash(hash: string) {
  try {
    return await provider.getBlock(hash)
  } catch (error) {
    console.error(`Error fetching block ${hash}:`, error)
    return null
  }
}

export async function getBlockWithTransactions(hash: string) {
  try {
    return await provider.getBlockWithTransactions(hash)
  } catch (error) {
    console.error(`Error fetching block with transactions ${hash}:`, error)
    return null
  }
}

export async function getTransaction(hash: string) {
  try {
    const tx = await provider.getTransaction(hash)
    if (!tx) return null

    const receipt = await provider.getTransactionReceipt(hash)

    return {
      ...tx,
      receipt,
    }
  } catch (error) {
    console.error(`Error fetching transaction ${hash}:`, error)
    return null
  }
}

